# user designed functions
# function 1: feature selection
FeatureSelection<-function(ts_train, varnames=colnames(ts_train), methodName, res_path){
  ts_train<-na.omit(ts_train)
  x<-as.matrix(ts_train[,2:ncol(ts_train)])
  y<-ts_train[,1]
  if (methodName=="lasso"){
    require(glmnet)
    cv<-cv.glmnet(x,y,lambda=seq(0.001,1,0.001)) # automatically select the value of lambda
    fit<-glmnet(x,y,type.gaussian="covariance",
                 lambda=cv$lambda.min)
    png(file = paste0(res_path,methodName,".png"),width =500, height = 500, units = "px")
    plot(cv)
    dev.off()
    coef=as.vector(predict(fit, type="coefficients"))
    feature_idx<-which(abs(coef)>0.2)
    feature_idx=feature_idx[-1]
    feature_name=varnames[feature_idx]
    selectfeature=list(names=feature_name, idx=feature_idx, lambda=cv$lambda.min)
  }
  if (methodName=="caret"){
    control <- trainControl(method="repeatedcv", number=10)
    model <- train(x_r~., data=ts_train, method='rpart',
                   preProcess="scale", trControl=control)
    importance <- varImp(model, scale=FALSE)
    feature_name<-rownames(importance$importance)
    feature_name<-feature_name[importance$importance>0.3]
    feature_idx<-match(feature_name, varnames)
    selectfeature<-list(names=feature_name, idx=feature_idx, importance=importance)
  }
  return(selectfeature)
}
# function 2: training function
train_module<-function(methodname="lm",train_dat,test_dat)
{
  require(caretEnsemble)
  ## step 1: find samples with na and omit the samples
  rownum_train=c(1:nrow(train_dat))
  complete_idx_train<-rownum_train[complete.cases(train_dat)]
  rownum_test<-c(1:nrow(test_dat))
  complete_idx_test<-rownum_test[complete.cases(test_dat)]
  
  train<-na.omit(train_dat)
  test<-na.omit(test_dat)
  ## step 2: divide the data into x and y for training model
  n_col<-ncol(train_dat)
  n_row<-nrow(train_dat)
  train_x<-train_dat[,2:n_col]
  train_y<-train_dat[,1]
  test_x<-test_dat[,2:n_col]
  test_y<-test_dat[,1]
  ## step 3: fit the models with different parameters
  fitControl=trainControl(method="repeatedcv",number=5,
                          savePredictions = "final",verboseIter = TRUE,
                          allowParallel = TRUE)
  criteria="RMSE"
  ppmethod=c("center", "scale")
  if ("gbm" %in% methodname){
    require(gbm)
    require(plyr)
    TuneGrid <- expand.grid(interaction.depth=13, n.trees=51*50, 
                            shrinkage=0.02,n.minobsinnode=30)
  }
  
  if ("knn" %in% methodname){
    require(FNN)
    TuneLength<-20
  }

  if (length(methodname)<2){
    if(methodname=="gbm"){
      fit=train(train_x,train_y,method=methodname,preProcess=ppmethod,
                metric=criteria,tuneGrid=TuneGrid,
                trControl=fitControl)
    }
    else
      fit=train(train_x,train_y,method=methodname,preProcess=ppmethod,
                metric=criteria,tuneLength = TuneLength,trControl=fitControl)
  }
  #Ensemble model
  if(length(methodname)>1){
    Trace=FALSE
    model_list=caretList(train_x,train_y, trControl=fitControl,preProcess=ppmethod,
                         trace=Trace, metric=criteria, methodList=methodname)
    fit<-caretEnsemble(model_list)
    methodname="ensemble"
  }
  complete_idx=list(complete_idx_train,complete_idx_test)
  perf=EvalFun(train_x,train_y,test_x,test_y,fit)
  VI=Flu_VarImp(train_dat,perf$train_p,fit,n_row,n_col)
  results=list(methodname=methodname,complete_sample_idx=complete_idx,FitModel=fit, EvalPerf=perf, VI=VI)
  if (length(methodname)< 2 & "knn" %in% methodname )
    results=list(methodname=methodname,complete_sample_idx=complete_idx,FitModel=fit,k=fit$bestTune$k,
                 EvalPerf=perf,VI=VI)
  return(results)
}


#function 4: xgboost
train_xgboost<-function(train_dat, test_dat,booster="gbtree"){
  xgb.fit <- xgboost(data = data.matrix(train_dat[,2:ncol(train_dat)]),
                     label = train_dat[,1],
                     booster = "gblinear", objective = "reg:linear",
                     colsample_bytree = 0.2, gamma = 0.1,
                     learning_rate = 0.05, max_depth = 10,
                     min_child_weight = 1.5, n_estimators = 7300,
                     reg_alpha = 0, reg_lambda = 0.1,
                     subsample = 0.5, seed = 123,
                     verbose = 0.7, nrounds = 8000,print_every_n=100)
  xgb.pred.train <- predict(xgb.fit, data.matrix(train_dat[,2:ncol(train_dat)]))
  xgb.pred.test<- predict(xgb.fit, data.matrix(test_dat[,2:ncol(test_dat)]))
  res<-postResample(xgb.pred.test, test_dat[,1])
  MAPE<-mean(abs((xgb.pred.test-test_dat[,1])/test_dat[,1]))*100
  return(list(xgb.pred=c(xgb.pred.train,xgb.pred.test), Evperf=c(res, MAPE)))
}


#function 6: Ensemble model
Train_test<-function(SelectAlgorithm=list("lm","glm","knn","nnet","svmLinear"
                                          ,c("lm","glm","knn","nnet","svmLinear")),train_dat,test_dat,auto=FALSE)
{
  Model_ensemble=list()
  method_len=length(SelectAlgorithm)
  test_MAPE=NULL
  for (i in 1:method_len)
  {
    print(paste("Training preditive model with ", SelectAlgorithm[i]))
    Model_ensemble[[i]]=train_module(SelectAlgorithm[[i]],train_dat,test_dat)
    test_RMSE=c(test_MAPE,Model_ensemble[[i]]$EvalPerf$metrics$Test_MAPE)
  }
  if (auto) # automatically select best model according to MAPE
  {
    min_idx=which.min(test_MAPE)
    Model_ensemble=Model_ensemble[[min_idx]]
  }
  
  return(Model_ensemble)
}


# function 5: prediction Function
predict_ensemble<-function(SelectAlgorithm,SelectModel,pred_data)
{
  Predict_value=list()
  critval=1.96
  for (i in 1:length(SelectAlgorithm)) {
    pred_value=predict(SelectModel[[i]]$FitModel,pred_data)
    delta=critval*sd(pred_value)
    Predict_value[[i]]=list(methodname=SelectAlgorithm[[i]],
                            Pred_val=cbind(pred_value,
                                           pred_value-delta,pred_value+delta))
  }
  return(Predict_value)
}
# function 6: predictive confidence intervals
model.predict<-function(SelectModel,pred_data,testSd)
{
  Predict_value=list()
  critval=1.96
  pred_value=predict(SelectModel,pred_data)
  delta=critval*testSd
  Predict_value=cbind(pred_value,pred_value-delta,pred_value+delta)
  return(Predict_value)
}
# function 7: Performance evaluation
EvalFun<-function(train_x,train_y,test_x,test_y,model)
{
  # Training
  Train_pred=predict(model,train_x)
  Train_RMSE=sqrt(mean((train_y-Train_pred)^2))
  Train_MAE=mean(abs(Train_pred-train_y))
  Train_MAPE<-100*mean(abs(Train_pred-train_y)/train_y)
  
  # Testing
  Test_val=predict(model, test_x)
  Test_RMSE=sqrt(mean((test_y-Test_val)^2))
  Test_MAE=mean(abs(test_y-Test_val))
  Test_MAPE<-100*mean(abs(test_y-Test_val)/test_y)
  
  EvalPerf=list(metrics=list(Train_RMSE=Train_RMSE,
                             Train_MAE=Train_MAE, 
                             Train_MAPE=Train_MAPE,
                             Test_RMSE=Test_RMSE,
                             Test_MAE=Test_MAE,
                             Test_MAPE=Test_MAPE),
                train_p=Train_pred,test_p=Test_val)
  return(EvalPerf)
}

#function 8: feature importance
Flu_VarImp<-function(train,Train_pred, FitModel,n_row,n_col)
{
  M1=train
  sample_idx=sample.int(n_row,size=n_row,replace=TRUE)
  M2=train[sample_idx,]
  N=list(0)
  for (i in 2:n_col)
  {
    N_reconstruct=M2
    N_reconstruct[,i]=M1[,i]
    N[[i-1]]=N_reconstruct
  }
  EY=mean(Train_pred)
  VY=sum(Train_pred^2)/(n_row-1)-EY^2
  U=rep(0,n_col-1)
  V_condition=rep(0,n_col-1)
  VI=rep(0,n_col-1)
  S=rep(0,n_col-1)
  for (i in 1:(n_col-1))
  {
    Pred_new=predict(FitModel,N[[i]][,-1])
    U[i]=crossprod(Train_pred,Pred_new)/(n_row-1)
    Pred_resample=predict(FitModel,M2[,-1])
    EY2=crossprod(Train_pred, Pred_resample)/n_row
    V_condition[i]=U[i]-EY2
  }
  S <- abs(V_condition/VY)
  VI <-S/sum(S)
  return(VI)
}

na.rm<-function(x){
  x[is.na(x)]<-mean(x,na.rm=T)
  return(x)
}
