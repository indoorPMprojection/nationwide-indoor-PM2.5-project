#Function 1: get RR for single city with specific cause of death
getCityRR<-function(cityCode,cityData) {
    #INPUT
    # 1. dfPM25
      # default: a maximum lag of 3 days; 
      # single-day lags[same day (lag 0) or 1, 2, 3], lag 1-lag 3;
      # exposures averaged over multiple lag days, lag 0-1, lag 0-2, lag 0-3;
      # PDLM estimates for cumulative exposures over the same day and 3, 6, 9 day prior (PDLM 0-3, 0-6, 0-9);
    # 2. dfTime
      # a natural cubic spline smooth function of calendar day with 7 degress of freedom (df)
         # per year to exclude seasonality in mortality;
    # 3. dfTemp: a cross-basis function of temperature built by the distributed lag nonlinear model
    #    (DLNM); natural cubic spline for the space with two internal knots at equality spaced
    #    log10 values of lags; select a cumulative lag over the same day and 13 day prior for temperature in the DLNM (DLNM 0-13)
    # 4. dfHum: a natural smooth function with 3 df for the present day relative humidity    
    #OUTPUT: varname, city code, RR, ci.low, ci.upper
  
    numOfYear<-length(unique(cityData$year))
    res<-NULL
    
    Mov_Temp<-rollmean(cityData$TEMP,3, fill=NA)
    Mov_Hum<-rollmean(cityData$HUM,3,fill=NA)
    ## Section 1: EXPLORING THE LAGGED (DELAYED) EFFECTS 
    #-----------------------------------------------------------------------------
    tablag_single <- matrix(NA,3+1,5,dimnames=list(paste("Lag",0:3), c("beta","beta.se","RR","ci.low","ci.hi"))) 
    for(i in 0:3) { 
     
      pm25Lag <- Lag(cityData$PM_25,i) /10
     
      mod <- glm(mortality ~ pm25Lag +ns(date, 7*numOfYear)+
                   ns(Mov_Temp,6)+ns(Mov_Hum,3)+dayofWeek, cityData, family=quasipoisson())
      
      tablag_single[i+1,] <- ci.lin(mod,subset="pm25Lag",Exp=T)[c(1:2,5:7)] 
    } 
    res<-rbind(res, tablag_single)
    
    ## Section 2: EXPLORING the moving average delayed EFFECTS 
    #-----------------------------------------------------------------------------
    tablag_moving<-matrix(NA, 3, 5,dimnames=list(paste0("Lag0-",1:3), c("beta","beta.se","RR","ci.low","ci.hi")))
    for(i in 2:4) { 
 
      pm25Mov <- rollmean(cityData$PM_25,i, fill=NA) /10
      mod <- glm(mortality ~ pm25Mov+ns(date, 7*numOfYear)+
                   ns(Mov_Temp,6)+ns(Mov_Hum,3)+dayofWeek, cityData, family=quasipoisson())
     
      tablag_moving[i-1,] <- ci.lin(mod,subset="pm25Mov",Exp=T)[c(1:2,5:7)] 
    } 
    res<-rbind(res, tablag_moving)
    
    ## Section 4: cbind the results
    #-----------------------------------------------------------------------------
    city<-rep(unique(cityData$city), nrow(res))
    loc<-rep(unique(cityData$location), nrow(res))
    res<-cbind(city,res)
    res<-cbind(res, loc)
    return(res)
}

